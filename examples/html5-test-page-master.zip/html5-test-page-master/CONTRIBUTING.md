# Contributing Guidelines

- ⇄ Pull requests and ★ Stars are always welcome.
- For bugs and feature requests, please create an issue.
- Pull requests must be accompanied by passing all existing automated tests (`$ npm test`).

Thanks in advance for helping out!
